Saudia 'en' homepage — AEM JCR package
======================================

jcr_root/content/saudia-eds/en/.content.xml
  -> the page node for /content/saudia-eds/en (Universal Editor authorable)

Import: place the jcr_root/ tree into an AEM content package (or use the
AEM package manager / crx) so it lands at /content/saudia-eds/en.
