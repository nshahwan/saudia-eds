Saudia homepage — content package for Universal Editor / Document Authoring
===========================================================================

HTML fragments (authored as EDS block tables):
  en.html      -> the "en" homepage
  nav.html     -> header/navigation fragment
  footer.html  -> footer fragment
  images/      -> all referenced images

Upload targets (Document Authoring — admin.da.live):
  en.html     -> {org}/{repo}/en
  nav.html    -> {org}/{repo}/nav
  footer.html -> {org}/{repo}/footer
  images/*    -> {org}/{repo}/images/<filename>

After upload: preview/publish in Document Authoring, then edit in Universal
Editor. Block models ship in the code repo (blocks/*/_*.json).
